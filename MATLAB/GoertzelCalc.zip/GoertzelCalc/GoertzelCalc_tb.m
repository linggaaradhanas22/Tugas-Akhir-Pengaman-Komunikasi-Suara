clear; clc;

%% About the test bench
% Filename: GoertzelCalc_tb

%% Parameter Configuration
Fs = 32000; % Sampling Frequency
duration = 0.020; % Duration for each tone
N = Fs * duration; % Number of samples
t = (0:N-1) / Fs; % Create a time vector

% Create coeff based on N and DTMF Frequency
    % Calculate k for each frequency
    k697 = round(0.5 + (N*697)/Fs);
    k770 = round(0.5 + (N*770)/Fs);
    k852 = round(0.5 + (N*852)/Fs);
    k941 = round(0.5 + (N*941)/Fs);
    k1209 = round(0.5 + (N*1209)/Fs);
    k1336 = round(0.5 + (N*1336)/Fs);
    k1477 = round(0.5 + (N*1477)/Fs);
    
    % Calculate coeff
    coeff697 = 2*cos(2*pi*k697/N);
    coeff770 = 2*cos(2*pi*k770/N);
    coeff852 = 2*cos(2*pi*k852/N);
    coeff941 = 2*cos(2*pi*k941/N);
    coeff1209 = 2*cos(2*pi*k1209/N);
    coeff1336 = 2*cos(2*pi*k1336/N);
    coeff1477 = 2*cos(2*pi*k1477/N);

    % Create a table for the coefficient values
coeffTable = table(coeff697, coeff770, coeff852, coeff941, coeff1209, coeff1336, coeff1477, ...
'VariableNames', {'Coeff_697', 'Coeff_770', 'Coeff_852', 'Coeff_941', 'Coeff_1209', 'Coeff_1336', 'Coeff_1477'});

%% DTMF Sample creation
x = zeros(1,length(t)); 
x(1) = 1; % Impulse function for generating tones

% Generate tones using filter function
y697 = filter([0 sin(2*pi*697/Fs)], [1 -2*cos(2*pi*697/Fs) 1], x);  
y770 = filter([0 sin(2*pi*770/Fs)], [1 -2*cos(2*pi*770/Fs) 1], x);  
y852 = filter([0 sin(2*pi*852/Fs)], [1 -2*cos(2*pi*852/Fs) 1], x);  
y941 = filter([0 sin(2*pi*941/Fs)], [1 -2*cos(2*pi*941/Fs) 1], x);  
y1209 = filter([0 sin(2*pi*1209/Fs)], [1 -2*cos(2*pi*1209/Fs) 1], x);  
y1336 = filter([0 sin(2*pi*1336/Fs)], [1 -2*cos(2*pi*1336/Fs) 1], x);  
y1477 = filter([0 sin(2*pi*1477/Fs)], [1 -2*cos(2*pi*1477/Fs) 1], x);

% Example tone: y697 + y1209 (digit 1)
xDTMF = y697 + y1209;

%% Calculation and plotting of the Goertzel filter
% Initialize arrays to store Q values at each iteration
Q0_history = zeros(1, N);
Q1_history = zeros(1, N);
Q2_history = zeros(1, N);
coeff_Q1_history = zeros(1, N);
x_min_Q2_history = zeros(1, N);

% Process each sample using GoertzelCalc
for n = 1:N
    [coeff_Q1, x_min_Q2, Q0, Q1, Q2] = GoertzelCalc(xDTMF(1:n), coeff697);
    
    % Store Q values
    Q0_history(n) = Q0;
    Q1_history(n) = Q1;
    Q2_history(n) = Q2;

    % Store intermediate value 
    coeff_Q1_history(n) = coeff_Q1;
    x_min_Q2_history(n) = x_min_Q2;
end

% Calculate the power value
[power, Q1_squared, Q2_squared, Q1_squared_plus_Q2_squared, coeff_Q1, coeff_Q1_Q2] = ComputeGoertzelPower(Q1, Q2, coeff697);

% Create a table to store all the variables
timePoints = t'; % Transpose to make it a column
xDTMF_col = xDTMF';
Q0_history_col = Q0_history';
Q1_history_col = Q1_history';
Q2_history_col = Q2_history';
coeff_Q1_history_col = coeff_Q1_history';
x_min_Q2_history_col = x_min_Q2_history';

% Combine all data into a table
goertzelTable = table(timePoints, xDTMF_col, Q0_history_col, Q1_history_col, ...
    Q2_history_col, coeff_Q1_history_col, x_min_Q2_history_col, ...
    'VariableNames', {'Time', 'DTMF_Signal', 'Q0', 'Q1', 'Q2', ...
    'Coeff_Q1', 'X_minus_Q2'});

% Create a separate table for the power-related values
powerTable = table(power, Q1_squared, Q2_squared, Q1_squared_plus_Q2_squared, coeff_Q1, coeff_Q1_Q2, ...
    'VariableNames', {'Power', 'Q1_Squared', 'Q2_Squared', 'Q1_Squared_Plus_Q2_Squared', 'Coeff_Q1', 'Coeff_Q1_Q2'});

% % Display the tables
% disp('Goertzel Filter Variables:');
% disp(goertzelTable);
% disp('Power-Related Values:');
% disp(powerTable);
% 
% 
% % Original plots in first figure
% figure('Name', 'Goertzel Filter Q Outputs for 697 Hz');
% % Plot Q0 history
% subplot(3,1,1);
% plot(t, Q0_history, 'b-');
% title('Q0 Output (697 Hz)');
% xlabel('Time (s)');
% ylabel('Amplitude');
% grid on;
% 
% % Plot Q1 history
% subplot(3,1,2);
% plot(t, Q1_history, 'r-');
% title('Q1 Output (697 Hz)');
% xlabel('Time (s)');
% ylabel('Amplitude');
% grid on;
% 
% % Plot Q2 history
% subplot(3,1,3);
% plot(t, Q2_history, 'g-');
% title('Q2 Output (697 Hz)');
% xlabel('Time (s)');
% ylabel('Amplitude');
% grid on;
% 
% % Adjust the spacing between subplots
% sgtitle('Goertzel Filter Q Values Response to 697 Hz DTMF Tone');
% 
% % New figure for coeff_Q1
% figure('Name', 'Goertzel Filter Coefficient Q1 Output');
% plot(t, coeff_Q1_history, 'm-');
% title('coeff*Q1 Output (697 Hz)');
% xlabel('Time (s)');
% ylabel('Amplitude');
% grid on;
% 
% % New figure for x_min_Q2
% figure('Name', 'Goertzel Filter x-Q2 Output');
% plot(t, x_min_Q2_history, 'k-');
% title('x-Q2 Output (697 Hz)');
% xlabel('Time (s)');
% ylabel('Amplitude');
% grid on;